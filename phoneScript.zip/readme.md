Instructions to Run the Software:

- Place the "phonescript.exe" somewhere(e.g c:/program)
- Open CMD in the same folder(cd c:/program)

- To Generate phone Numbers run following command:
/> honescript.exe generate 500

- To Import & Validate phone Numbers run following command:
/> phonescript.exe import /PhoneNumbersGenerated.csv